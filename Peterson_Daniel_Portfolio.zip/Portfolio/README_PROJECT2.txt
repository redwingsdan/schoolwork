The program is compiled as project2 from the source file project2.cpp
To run, in the terminal one can compile the source file with the
following command:
'g++ project2.cpp -o project2' to create an executable file called 'project2'.
The user should then create a file called 'file1' using the command 'touch file1'.

To edit this file, the user should use the command 'nano file1' and then an edit window
should appear. The user can then copy or type any text that they would like into the the file
and then save it. This file contains the data which will be copied to the second file.

By typing in ./project2, the program will be run will output the monitoring
table when it has completed and a statement "File Transfer Completed".

There should be a new file created called file2 which contains the text which the user
put into file1