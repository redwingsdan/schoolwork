The program is compiled as main from the source file main.cpp.
To run, in the terminal one can compile the source file with the following command:
'g++ main.cpp -o main' to create an executable file called 'main'.
By typing in ./main, the program will be run and a command line will appear.
By entering commands into this command line, operations can be performed.

$ 'echo hello > file2' - creates a file named 'file2' with the arguments prior to it
$ 'cat file' - reads the contents of the file named 'file'
$ 'gedit &' - opens up the program gedit in the background

Typing 'exit' quits the program.