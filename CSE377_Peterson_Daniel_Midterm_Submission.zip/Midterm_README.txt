Daniel Peterson - 109091561

Each question is submitted in its own folder.

Each question is answered in comments within the matlab script file in the respective folder.

Any matlab functions which were used are also present in the matlab script file ready to be run.

The resulting images are saved after each time the script is run, sample images are also provided for each question.
