%Daniel Peterson - 109091561

%The term watershed refers to the region between two areas that divides
%the two systems. In a way, this is similar to an edge in an image, which
%divides objects. The watershed segmentation method divides images by
%determining which pixels belong with which objects. The watershed method
%treats images as surfaces, where dark areas are low and bright areas are
%high. By applying the watershed method, the edges of the image, where the
%high and low areas meet, become the ridges and defines those areas


%load all images and call watershed function
img = imread('SEG1.tif');
b = img(:,:,1);
calcWatershed(b);

img = imread('SEG2a.tif');
b = img(:,:,1);
calcWatershed(b);

img = imread('SEG2b.tif');
b = img(:,:,1);
calcWatershed(b);

img = imread('SEG2c.tif');
b = img(:,:,1);
calcWatershed(b);

img = imread('SEG3a.tif');
b = img(:,:,1);
calcWatershed(b);

img = imread('SEG3b.tif');
b = img(:,:,1);
calcWatershed(b);

img = imread('SEG3c.tif');
b = img(:,:,1);
calcWatershed(b);

%calculates and displays the watershed transform
function x = calcWatershed(b)
%shows original image
figure
imshow(b, [], 'InitialMagnification', 'fit');
title('Original B/W Image')

%removes background and creates distance transform
threshold = 128;    %background color
b = (b ~= threshold);%get all objects not in background
D = bwdist(~b);
figure
imshow(D,[],'InitialMagnification','fit')
title('Distance transform of image')

%calculates the watershed of the distance transform and displays
D = -D;
D(~b) = Inf;    %remove background pixels
L = watershed(D);
L(~b) = 0;      %label background as 0
rgb = label2rgb(L,'jet',[.5 .5 .5]);
figure
imshow(rgb,'InitialMagnification','fit')
title('Watershed transform of image')

end