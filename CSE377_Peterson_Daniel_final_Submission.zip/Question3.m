%Daniel Peterson - 109091561

%The following segments each image by basic segmentation and chan-vese
%segmentation. Area_error# represents the error in area for shape#, the
%percentage is represented by the respective name as well. True_area#
%represents the true area of shape# based on the object's parameters upon
%creation. Label_error# represents the labeling error for shape# as a
%percentage. Total_area_error represents the total error for all objects as
%a percentage

img = imread('SEG1.tif');
b = img(:,:,1);
calcError(b);   %thresholding
%chan-vese
mask = zeros(size(img,1),size(img,2));
mask(10:150,140:250) = 1;
region_seg(I, m, 200); %-- Run segmentation for 200 iterations

img = imread('SEG2a.tif');
b = img(:,:,1);
calcError(b);%thresholding
%chan-vese
mask = zeros(size(img,1),size(img,2));
mask(10:150,140:250) = 1;
region_seg(I, m, 200); %-- Run segmentation for 200 iterations

img = imread('SEG2b.tif');
b = img(:,:,1);
calcError(b);%thresholding
%chan-vese
mask = zeros(size(img,1),size(img,2));
mask(10:150,140:250) = 1;
region_seg(I, m, 200); %-- Run segmentation for 200 iterations

img = imread('SEG2c.tif');
b = img(:,:,1);
calcError(b);%thresholding
%chan-vese
mask = zeros(size(img,1),size(img,2));
mask(10:150,140:250) = 1;
region_seg(I, m, 200); %-- Run segmentation for 200 iterations

img = imread('SEG3a.tif');
b = img(:,:,1);
calcError(b);%thresholding
%chan-vese
mask = zeros(size(img,1),size(img,2));
mask(10:150,140:250) = 1;
region_seg(I, m, 200); %-- Run segmentation for 200 iterations

img = imread('SEG3b.tif');
b = img(:,:,1);
calcError(b);%thresholding
%chan-vese
mask = zeros(size(img,1),size(img,2));
mask(10:150,140:250) = 1;
region_seg(I, m, 200); %-- Run segmentation for 200 iterations

img = imread('SEG3c.tif');
b = img(:,:,1);
calcError(b);%thresholding
%chan-vese
mask = zeros(size(img,1),size(img,2));
mask(10:150,140:250) = 1;
region_seg(I, m, 200); %-- Run segmentation for 200 iterations

%The following code was found online and implements chan-vese segmentation
%The images are read and a mask is applied to differentiate between the
%foreground and background. The initial area expands and contours around
%edges when it finds other objects
function region_seg(img,mask,max_iterations,alpha,display)
  
  %-- default value for parameter alpha is .1
  if(~exist('alpha','var')) 
    alpha = .2; 
  end
  %-- default behavior is to display intermediate outputs
  if(~exist('display','var'))
    display = true;
  end
  I = im2graydouble(img);    
  phi = bwdist(mask)-bwdist(1-mask)+im2double(mask)-.5;
  
  %--main loop
  for iterations = 1:max_iterations   % Note: no automatic convergence test

    idx = find(phi <= 1.2 & phi >= -1.2);  %get the curve's narrow band
    
    %-- find interior and exterior mean
    upts = find(phi<=0);                 % interior points
    vpts = find(phi>0);                  % exterior points
    u = sum(I(upts))/(length(upts)+eps); % interior mean
    v = sum(I(vpts))/(length(vpts)+eps); % exterior mean
    
    F = (I(idx)-u).^2-(I(idx)-v).^2;         % force from image information
    curvature = get_curvature(phi,idx);  % force from curvature penalty
    
    dphidt = F./max(abs(F)) + alpha*curvature;  % gradient descent to minimize energy
    
    %-- maintain the CFL condition
    dt = .45/(max(dphidt)+eps);
        
    %-- evolve the curve
    phi(idx) = phi(idx) + dt.*dphidt;

    %-- Keep SDF smooth
    phi = sussman(phi, .5);
  end
  segmented_image = phi<=0;  
  figure; 
  imshow(img); 
  title('Original Image');
  figure; 
  imshow(mask); 
  title('Initial Mask');
  figure; 
  imshow(segmented_image); 
  title('Final Chan-Vese');
  
  true_area1 = 1800;
  true_area2 = 700;
  true_area3 = 31415;
  true_area4 = 2500;
  true_area5 = 6283;
  true_area6 = 1100;
  true_sum = true_area1 + true_area2 + true_area3 + true_area4 + true_area5 + true_area6;
  areaAll = bwarea(segmented_image);
  label_error_all = 100 * abs(true_sum-areaAll)/true_sum;
  
end
function curvature = get_curvature(phi,idx)
    [dimy, dimx] = size(phi);        
    [y x] = ind2sub([dimy,dimx],idx);  % get subscripts

    %-- get subscripts of neighbors
    ym1 = y-1; xm1 = x-1; yp1 = y+1; xp1 = x+1;

    %-- bounds checking  
    ym1(ym1<1) = 1; xm1(xm1<1) = 1;              
    yp1(yp1>dimy)=dimy; xp1(xp1>dimx) = dimx;    

    %-- get indexes for 8 neighbors
    idup = sub2ind(size(phi),yp1,x);    
    iddn = sub2ind(size(phi),ym1,x);
    idlt = sub2ind(size(phi),y,xm1);
    idrt = sub2ind(size(phi),y,xp1);
    idul = sub2ind(size(phi),yp1,xm1);
    idur = sub2ind(size(phi),yp1,xp1);
    iddl = sub2ind(size(phi),ym1,xm1);
    iddr = sub2ind(size(phi),ym1,xp1);
    
    %-- get central derivatives of SDF at x,y
    phi_x  = -phi(idlt)+phi(idrt);
    phi_y  = -phi(iddn)+phi(idup);
    phi_xx = phi(idlt)-2*phi(idx)+phi(idrt);
    phi_yy = phi(iddn)-2*phi(idx)+phi(idup);
    phi_xy = -0.25*phi(iddl)-0.25*phi(idur)...
             +0.25*phi(iddr)+0.25*phi(idul);
    phi_x2 = phi_x.^2;
    phi_y2 = phi_y.^2;
    
    %-- compute curvature
    curvature = ((phi_x2.*phi_yy + phi_y2.*phi_xx - 2*phi_x.*phi_y.*phi_xy)./...
              (phi_x2 + phi_y2 +eps).^(3/2)).*(phi_x2 + phi_y2).^(1/2);        
  end
%-- Converts image to one channel (grayscale) double
function img = im2graydouble(img)    
  [dimy, dimx, c] = size(img);
  if(isfloat(img)) % image is a double
    if(c==3) 
      img = rgb2gray(uint8(img)); 
    end
  else           % image is a int
    if(c==3) 
      img = rgb2gray(img); 
    end
    img = double(img);
  end
end
%-- level set re-initialization by the sussman method
function D = sussman(D, dt)
  % forward/backward differences
  a = D - shiftR(D); % backward
  b = shiftL(D) - D; % forward
  c = D - shiftD(D); % backward
  d = shiftU(D) - D; % forward
  
  a_p = a;  a_n = a; % a+ and a-
  b_p = b;  b_n = b;
  c_p = c;  c_n = c;
  d_p = d;  d_n = d;
  
  a_p(a < 0) = 0;
  a_n(a > 0) = 0;
  b_p(b < 0) = 0;
  b_n(b > 0) = 0;
  c_p(c < 0) = 0;
  c_n(c > 0) = 0;
  d_p(d < 0) = 0;
  d_n(d > 0) = 0;
  
  dD = zeros(size(D));
  D_neg_ind = find(D < 0);
  D_pos_ind = find(D > 0);
  dD(D_pos_ind) = sqrt(max(a_p(D_pos_ind).^2, b_n(D_pos_ind).^2) ...
                       + max(c_p(D_pos_ind).^2, d_n(D_pos_ind).^2)) - 1;
  dD(D_neg_ind) = sqrt(max(a_n(D_neg_ind).^2, b_p(D_neg_ind).^2) ...
                       + max(c_n(D_neg_ind).^2, d_p(D_neg_ind).^2)) - 1;
  
  D = D - dt .* D ./ sqrt(D.^2 + 1) .* dD;
  end

function shift = shiftD(M)
  shift = shiftR(M')';
end
function shift = shiftL(M)
  shift = [ M(:,2:size(M,2)) M(:,size(M,2)) ];
end
function shift = shiftR(M)
  shift = [ M(:,1) M(:,1:size(M,2)-1) ];
end
function shift = shiftU(M)
  shift = shiftL(M')';
end

%Thresholds images and calculates area and labeling error
function x = calcError(b)
%BASIC THRESHOLDING
true_area1 = 1800;
true_area2 = 700;
true_area3 = 31415;
true_area4 = 2500;
true_area5 = 6283;
true_area6 = 1100;

%Segmentation of images by thresholding
threshold = 240;
shape1 = b > threshold;
area1 = bwarea(shape1); %1800

threshold = 230;
shape2 = (b == threshold);
area2 = bwarea(shape2); %700

threshold = 204;
shape3 = (b == threshold);
area3 = bwarea(shape3); %31,415

threshold = 153;
shape4 = (b == threshold);
area4 = bwarea(shape4); %2500

threshold = 102;
shape5 = (b == threshold);
area5 = bwarea(shape5); %6283

threshold = 51;
shape6 = (b == threshold);
area6 = bwarea(shape6); %1100

threshold = 128;
allshapes = (b ~= threshold);
areaAll = bwarea(allshapes);

%Area error
true_sum = true_area1 + true_area2 + true_area3 + true_area4 + true_area5 + true_area6;
area_error = (1-((true_sum - area1)/true_sum));
area_error2 = (1-((true_sum - area2)/true_sum));
area_error3 = (1-((true_sum - area3)/true_sum));
area_error4 = (1-((true_sum - area4)/true_sum));
area_error5 = (1-((true_sum - area5)/true_sum));
area_error6 = (1-((true_sum - area6)/true_sum));
area_error_percentage = 100 * area_error;
area_error2_percentage = 100 * area_error2;
area_error3_percentage = 100 * area_error3;
area_error4_percentage = 100 * area_error4;
area_error5_percentage = 100 * area_error5;
area_error6_percentage = 100 * area_error6;
total_area_error = 100 * (area_error + area_error2 + area_error3 + area_error4 + area_error5 + area_error6);

%Labeling error
label_error = 100 * abs(true_area1-area1)/true_area1;
label_error2 = 100 * abs(true_area2-area2)/true_area2;
label_error3 = 100 * abs(true_area3-area3)/true_area3;
label_error4 = 100 * abs(true_area4-area4)/true_area4;
label_error5 = 100 * abs(true_area5-area5)/true_area5;
label_error6 = 100 * abs(true_area6-area6)/true_area6;

%Segmented shapes from image
figure;
imshow(shape1);
title('Shape 1');
figure;
imshow(shape2);
title('Shape 2');
figure;
imshow(shape3);
title('Shape 3');
figure;
imshow(shape4);
title('Shape 4');
figure;
imshow(shape5);
title('Shape 5');
figure;
imshow(shape6);
title('Shape 6');
figure;
imshow(allshapes);
title('All Shapes');
end