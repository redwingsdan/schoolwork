%Daniel Peterson - 109091561

%This calculates the area error and labeling error for the original image
%The true (based on input length and width) area of the images is provided
%and the area calculated by matlab is calculated. The two results are then
%compared and the error is determined

img = imread('SEG1.tif');
b = img(:,:,1);

true_area1 = 1800;
shape1 = b > 240;
area1 = bwarea(shape1); %1800

true_area2 = 700;
shape2 = b == 230;
area2 = bwarea(shape2); %700

true_area3 = 31415;
shape3 = b == 204;
area3 = bwarea(shape3); %31,415

true_area4 = 2500;
shape4 = b == 153;
area4 = bwarea(shape4); %2500

true_area5 = 6283;
shape5 = b == 102;
area5 = bwarea(shape5); %6283

true_area6 = 1100;
shape6 = b  == 51;
area6 = bwarea(shape6); %1100

true_sum = true_area1 + true_area2 + true_area3 + true_area4 + true_area5 + true_area6;
area_error = (1-((true_sum - area1)/true_sum));
area_error2 = (1-((true_sum - area2)/true_sum));
area_error3 = (1-((true_sum - area3)/true_sum));
area_error4 = (1-((true_sum - area4)/true_sum));
area_error5 = (1-((true_sum - area5)/true_sum));
area_error6 = (1-((true_sum - area6)/true_sum));
area_error_percentage = 100 * area_error;
area_error2_percentage = 100 * area_error2;
area_error3_percentage = 100 * area_error3;
area_error4_percentage = 100 * area_error4;
area_error5_percentage = 100 * area_error5;
area_error6_percentage = 100 * area_error6;
total_area_error = 100*(area_error + area_error2 + area_error3 + area_error4 + area_error5 + area_error6);

label_error = 100 * abs(true_area1-area1)/true_area1;
label_error2 = 100 * abs(true_area2-area2)/true_area2;
label_error3 = 100 * abs(true_area3-area3)/true_area3;
label_error4 = 100 * abs(true_area4-area4)/true_area4;
label_error5 = 100 * abs(true_area5-area5)/true_area5;
label_error6 = 100 * abs(true_area6-area6)/true_area6;
