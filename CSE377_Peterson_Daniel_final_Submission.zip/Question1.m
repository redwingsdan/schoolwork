%Daniel Peterson - 109091561

%6 shapes (3 rectanges, 1 circle, 1 square, and one ellipse) are created
%and placed on an image. The image has a 128 pixel value background so it
%is exactly in the middle of the intensity spectrum. Some of the images are
%brighter than the background and some are darker. Additive gaussian noise
%and impulse noise is also added to the image in 3 discrete intervals. For
%additive gaussian noise, the first variance is based on the image and is
%about 0.06. The following two variances are 0.1 and 0.2, which results in
%a grainier image as the variance increases. The impulse noise is applied
%with a random value with a given intensity. The initial intensity is 0.2,
%then 0.4 and then down to 0.05. The higher the intensity, the grainier the
%image becomes. 

I = imread('cameraman.tif');
img = I(:,:,1);
image_thresholded = img;
image_thresholded(img>3) = 128; %make background gray
fh = figure;
imshow(image_thresholded, []);
hold on;
%make shapes
rectangle('Position', [50 70 30 60], 'FaceColor', [1 1 1]);%1800
rectangle('Position', [30 80 10 70], 'FaceColor', [0.8 0.8 0.8]);%700
rectangle('Position', [100 100 100 100], 'FaceColor', [0.2 0.2 0.2], 'Curvature', [1 1]);%31,415
rectangle('Position', [40 180 50 50], 'FaceColor', [0.4 0.4 0.4]); %2500
rectangle('Position', [20 20 200 10], 'FaceColor', [0.6 0.6 0.6], 'Curvature', [1 1]); %6283
rectangle('Position', [90 45 110 10], 'FaceColor', [0.9 0.9 0.9]); %1100
frm = getframe(fh);
%imwrite(image_thresholded, 'SEG1.tif', 'tif');
imwrite(frm.cdata, 'SEG1.tif');

imagearea = frm.cdata ~= 128;   
%Calculate measurements for the image
areas = regionprops(imagearea, 'Area');

%add gaussian noise to the image
[myimage, map] = imread('SEG1.tif');
myimage = double(myimage) / 255;
v = var(myimage(:));
mean = 0;
Igauss = imnoise(myimage, 'gaussian', mean, v);
v = 0.1;
Igauss2 = imnoise(myimage, 'gaussian', mean, v);
v = 0.2;
Igauss3 = imnoise(myimage, 'gaussian', mean, v);

%add impulse noise to the image
randomimage = im2double(imread('SEG1.tif'));
p = 0.2;
Irand = (randomimage + p*rand(size(randomimage)))/(1+p);
p = 0.4;
Irand2 = (randomimage + p*rand(size(randomimage)))/(1+p);
p = 0.05;
Irand3 = (randomimage + p*rand(size(randomimage)))/(1+p);
figure;
imshow([randomimage Irand Igauss Irand2 Igauss2 Irand3 Igauss3]);

%save all images
imwrite(Irand, 'SEG3a.tif');
imwrite(Irand2, 'SEG3b.tif');
imwrite(Irand3, 'SEG3c.tif');
imwrite(Igauss, 'SEG2a.tif');
imwrite(Igauss2, 'SEG2b.tif');
imwrite(Igauss3, 'SEG2c.tif');