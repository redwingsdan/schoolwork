%Daniel Peterson - 109091561

%I'm not really sure how do approach this problem so I attempted to load
%the image and discretize the heat equations for the x and y domains
%Three iterations take place, from 0 to 1 in 0.1 increments (10), from 0 to
%10 in 0.1 increments (100) and from 0 to 100 in 0.1 increments (1000) for
%the image
img = imread('heart.jpg');
h = img(:,:,1);
applyHeat10(h);
applyHeat100(h);
applyHeat1000(h);

function applyHeat10(h)
figure;
imshow(h);
title('Original Image');
dt = 0.1;
T = 1;
[m,n]=size(h);
for t = 0:dt:T
h_xx = h(:,[2:n,n])-2*h +h(:,[1,1:n-1]);
h_yy = h([2:m,m],:) - 2*h + h([1,1:m-1],:);
 L = h_xx + h_yy;
 h = h + dt*L;
end
figure;
imshow(h)
title('Smoothed Image');
end

function applyHeat100(h)
figure;
imshow(h);
title('Original Image');
dt = 0.1;
T = 10;
[m,n]=size(h);
for t = 0:dt:T
h_xx = h(:,[2:n,n])-2*h +h(:,[1,1:n-1]);
h_yy = h([2:m,m],:) - 2*h + h([1,1:m-1],:);
 L = h_xx + h_yy;
 h = h + dt*L;
end
figure;
imshow(h)
title('Smoothed Image');
end

function applyHeat1000(h)
figure;
imshow(h);
title('Original Image');
dt = 0.1;
T = 100;
[m,n]=size(h);
for t = 0:dt:T
h_xx = h(:,[2:n,n])-2*h +h(:,[1,1:n-1]);
h_yy = h([2:m,m],:) - 2*h + h([1,1:m-1],:);
 L = h_xx + h_yy;
 h = h + dt*L;
end
figure;
imshow(h)
title('Smoothed Image');
end